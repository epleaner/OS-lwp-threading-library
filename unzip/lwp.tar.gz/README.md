# OS-lwp-threading-library
Lightweight threading library written in C for CSC 453: Operating Systems

Written for a 32 bit OS.

To run:
'make all'

Execute numbersmain, snakemain, or hungrymain.
